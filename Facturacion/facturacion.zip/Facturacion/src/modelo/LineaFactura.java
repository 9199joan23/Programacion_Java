/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author 9199.joan23
 */
public class LineaFactura {
    
      private int lin_id;

    public LineaFactura() {
    }

    public LineaFactura(int lin_id) {
        this.lin_id = lin_id;
    }

    public int getLin_id() {
        return lin_id;
    }

    public void setLin_id(int lin_id) {
        this.lin_id = lin_id;
    }
      
      
    
}
